import { useEffect, useState } from "react";
import { useNavigate, useLocation, Outlet } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { BarChart3, FileText, Upload, History, CheckCircle, MessageSquare, ClipboardList, TrendingUp, LogOut, Search } from "lucide-react";
import type { User } from "@supabase/supabase-js";

const navItems = [
  { section: "Overview", items: [
    { label: "Dashboard", icon: BarChart3, path: "/dashboard" },
  ]},
  { section: "Documents", items: [
    { label: "All Documents", icon: FileText, path: "/documents" },
    { label: "Upload", icon: Upload, path: "/upload" },
    { label: "Version History", icon: History, path: "/versions" },
  ]},
  { section: "Workflow", items: [
    { label: "Approvals", icon: CheckCircle, path: "/approvals" },
    { label: "Comments", icon: MessageSquare, path: "/comments" },
  ]},
  { section: "Admin", items: [
    { label: "Audit Trail", icon: ClipboardList, path: "/audit" },
    { label: "Reports", icon: TrendingUp, path: "/reports" },
  ]},
];

const AppLayout = () => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<{ first_name: string; last_name: string; role: string } | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (!session?.user) navigate("/auth");
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (!session?.user) navigate("/auth");
    });
    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("first_name, last_name, role").eq("user_id", user.id).single()
      .then(({ data }) => { if (data) setProfile(data); });
  }, [user]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  const displayName = profile ? `${profile.first_name} ${profile.last_name}`.trim() || user?.email?.split("@")[0] : user?.email?.split("@")[0] || "User";
  const initial = displayName[0]?.toUpperCase() || "U";

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-60 bg-card border-r border-border flex flex-col fixed top-0 left-0 h-screen z-50">
        <div className="p-5 border-b border-border flex items-center gap-2.5">
          <div className="w-[30px] h-[30px] gradient-brand rounded-lg flex items-center justify-center text-[15px]">🔐</div>
          <div className="font-display font-extrabold text-base tracking-tight">Secure<span className="text-primary">Portal</span></div>
        </div>

        <nav className="flex-1 p-3 overflow-y-auto space-y-5">
          {navItems.map(section => (
            <div key={section.section}>
              <div className="text-[10px] font-semibold text-muted-foreground/50 uppercase tracking-[1.5px] px-2.5 mb-1.5">{section.section}</div>
              {section.items.map(item => {
                const active = location.pathname === item.path;
                return (
                  <button key={item.path} onClick={() => navigate(item.path)}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-[13px] font-medium transition-all mb-0.5 ${active ? "bg-primary/10 text-primary border border-primary/20" : "text-muted-foreground hover:bg-surface2 hover:text-foreground"}`}>
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="p-3.5 border-t border-border flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full gradient-brand flex items-center justify-center text-[13px] font-bold text-secondary-foreground shrink-0">{initial}</div>
          <div className="flex-1 min-w-0">
            <div className="text-[13px] font-semibold truncate">{displayName}</div>
            <div className="text-[11px] text-muted-foreground capitalize">{profile?.role || "User"}</div>
          </div>
          <button onClick={handleLogout} className="text-muted-foreground/50 hover:text-destructive transition-colors" title="Logout">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="ml-60 flex-1">
        <div className="bg-card border-b border-border px-7 h-[60px] flex items-center justify-between sticky top-0 z-40">
          <h2 className="font-display text-xl font-bold capitalize">
            {location.pathname.slice(1) || "Dashboard"}
          </h2>
          <div className="flex gap-2.5 items-center">
            <div className="flex items-center gap-2 bg-background border border-border-bright rounded-lg px-3 py-1.5 w-60">
              <Search className="w-4 h-4 text-muted-foreground/50" />
              <input type="text" placeholder="Search documents..." className="bg-transparent border-none outline-none text-foreground text-[13px] flex-1 placeholder:text-muted-foreground/50" />
            </div>
            <span className="inline-flex items-center gap-1.5 text-[11px] font-mono bg-primary/[0.07] border border-primary/20 text-primary rounded px-2 py-0.5">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse-dot" /> Encrypted
            </span>
            <button onClick={() => navigate("/upload")} className="px-4 py-2 rounded-lg text-[13px] font-semibold bg-primary/[0.12] text-primary border border-primary/30 hover:bg-primary/20 transition-all">
              + Upload
            </button>
          </div>
        </div>
        <div className="p-7 animate-fade-in">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AppLayout;
