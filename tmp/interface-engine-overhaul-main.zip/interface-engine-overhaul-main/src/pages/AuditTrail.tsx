import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface AuditLog {
  id: string;
  action: string;
  detail: string | null;
  created_at: string;
  user_id: string | null;
}

const actionColors: Record<string, string> = {
  UPLOAD: "text-primary",
  APPROVE: "text-success",
  REJECT: "text-destructive",
  COMMENT: "text-secondary",
  LOGIN: "text-warning",
  DOWNLOAD: "text-foreground",
};

const AuditTrail = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);

  useEffect(() => {
    supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(50)
      .then(({ data }) => { if (data) setLogs(data); });
  }, []);

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-5 py-4 border-b border-border flex items-center justify-between">
        <h3 className="font-display text-sm font-bold">Audit Log</h3>
      </div>
      <div className="p-5">
        {logs.length === 0 ? (
          <div className="text-center text-muted-foreground text-sm py-6">No audit logs yet.</div>
        ) : (
          logs.map(log => (
            <div key={log.id} className="flex items-center gap-4 py-2.5 border-b border-border text-xs">
              <div className="font-mono text-muted-foreground min-w-[100px]">{new Date(log.created_at).toLocaleString()}</div>
              <div className={`font-semibold min-w-[80px] ${actionColors[log.action] || "text-foreground"}`}>{log.action}</div>
              <div className="text-muted-foreground">{log.detail || "—"}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AuditTrail;
