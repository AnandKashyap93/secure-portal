import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const Reports = () => {
  const [stats, setStats] = useState({ total: 0, approved: 0, rejected: 0, pending: 0, draft: 0 });

  useEffect(() => {
    supabase.from("documents").select("status").then(({ data }) => {
      if (data) {
        setStats({
          total: data.length,
          approved: data.filter(d => d.status === "approved").length,
          rejected: data.filter(d => d.status === "rejected").length,
          pending: data.filter(d => d.status === "pending").length,
          draft: data.filter(d => d.status === "draft").length,
        });
      }
    });
  }, []);

  const breakdown = [
    { label: "Approved", count: stats.approved, pct: stats.total ? Math.round(stats.approved / stats.total * 100) : 0, color: "bg-success" },
    { label: "Rejected", count: stats.rejected, pct: stats.total ? Math.round(stats.rejected / stats.total * 100) : 0, color: "bg-destructive" },
    { label: "Pending", count: stats.pending, pct: stats.total ? Math.round(stats.pending / stats.total * 100) : 0, color: "bg-warning" },
    { label: "Draft", count: stats.draft, pct: stats.total ? Math.round(stats.draft / stats.total * 100) : 0, color: "bg-muted-foreground" },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border font-display text-sm font-bold">Approval Breakdown</div>
        <div className="p-5">
          <div className="font-display text-3xl font-extrabold mb-4">{stats.total} <span className="text-sm text-muted-foreground">total</span></div>
          {breakdown.map(b => (
            <div key={b.label} className="flex items-center gap-3 mb-2.5">
              <div className={`w-2.5 h-2.5 rounded-sm ${b.color}`} />
              <div className="text-xs flex-1">{b.label}</div>
              <div className="text-xs font-mono text-muted-foreground">{b.pct}% · {b.count}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border font-display text-sm font-bold">Summary</div>
        <div className="p-5">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Your portal has <strong className="text-foreground">{stats.total}</strong> documents total.
            {stats.pending > 0 && <> <strong className="text-warning">{stats.pending}</strong> are awaiting approval.</>}
            {stats.approved > 0 && <> <strong className="text-success">{stats.approved}</strong> have been approved.</>}
          </p>
          <div className="h-1 bg-border rounded-full mt-4 overflow-hidden flex">
            {breakdown.map(b => (
              <div key={b.label} className={`h-full ${b.color} transition-all`} style={{ width: `${b.pct}%` }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
