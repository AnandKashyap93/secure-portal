import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { FileText, Clock, CheckCircle, Users } from "lucide-react";

interface Document {
  id: string;
  title: string;
  filename: string;
  status: string;
  version: string;
  file_size: number;
  created_at: string;
}

const statusStyles: Record<string, string> = {
  pending: "bg-warning/15 text-warning",
  approved: "bg-success/15 text-success",
  rejected: "bg-destructive/15 text-destructive",
  draft: "bg-muted-foreground/15 text-muted-foreground",
};

const Dashboard = () => {
  const [docs, setDocs] = useState<Document[]>([]);
  const [counts, setCounts] = useState({ total: 0, pending: 0, approved: 0 });
  const navigate = useNavigate();

  useEffect(() => {
    supabase.from("documents").select("*").order("created_at", { ascending: false }).limit(5)
      .then(({ data }) => {
        if (data) setDocs(data);
      });
    supabase.from("documents").select("status").then(({ data }) => {
      if (data) {
        setCounts({
          total: data.length,
          pending: data.filter(d => d.status === "pending").length,
          approved: data.filter(d => d.status === "approved").length,
        });
      }
    });
  }, []);

  const stats = [
    { icon: FileText, value: counts.total, label: "Total Documents", delta: "All time", color: "primary" },
    { icon: Clock, value: counts.pending, label: "Pending Approvals", delta: "Requires action", color: "warning" },
    { icon: CheckCircle, value: counts.approved, label: "Approved", delta: "Completed", color: "success" },
    { icon: Users, value: 0, label: "Active Users", delta: "In your org", color: "secondary" },
  ];

  const colorMap: Record<string, string> = {
    primary: "from-primary to-primary/70",
    warning: "from-warning to-warning/70",
    success: "from-success to-success/70",
    secondary: "from-secondary to-secondary/70",
  };

  return (
    <div>
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-7">
        {stats.map(s => (
          <div key={s.label} className="bg-card border border-border rounded-xl p-5 relative overflow-hidden">
            <div className={`absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${colorMap[s.color]}`} />
            <s.icon className="w-5 h-5 mb-3 text-muted-foreground" />
            <div className="font-display text-3xl font-extrabold leading-none">{s.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
            <div className={`text-[11px] mt-2 ${s.color === "warning" ? "text-warning" : "text-success"}`}>{s.delta}</div>
          </div>
        ))}
      </div>

      {/* Recent docs + activity */}
      <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-5">
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border flex items-center justify-between">
            <h3 className="font-display text-sm font-bold">Recent Documents</h3>
            <button onClick={() => navigate("/documents")} className="text-xs text-muted-foreground hover:text-foreground px-2.5 py-1 rounded border border-border-bright transition-all">View All</button>
          </div>
          {docs.length === 0 ? (
            <div className="p-10 text-center text-muted-foreground text-sm">No documents yet. Upload your first one!</div>
          ) : (
            docs.map(doc => (
              <div key={doc.id} className="flex items-center gap-3.5 px-5 py-3 border-b border-border hover:bg-surface2 transition-colors cursor-pointer">
                <div className="w-[38px] h-[38px] bg-surface2 border border-border-bright rounded-lg flex items-center justify-center text-lg shrink-0">📄</div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13px] font-semibold truncate">{doc.title}</div>
                  <div className="text-[11px] text-muted-foreground font-mono">{doc.filename} · {doc.version} · {(doc.file_size / 1024 / 1024).toFixed(1)} MB</div>
                </div>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded capitalize ${statusStyles[doc.status] || statusStyles.draft}`}>{doc.status}</span>
              </div>
            ))
          )}
        </div>

        <div className="flex flex-col gap-5">
          <div className="bg-card border border-border rounded-xl">
            <div className="px-5 py-4 border-b border-border">
              <h3 className="font-display text-sm font-bold">Storage</h3>
            </div>
            <div className="p-5">
              <div className="font-display text-2xl font-extrabold">
                {(docs.reduce((a, d) => a + d.file_size, 0) / 1024 / 1024).toFixed(1)} <span className="text-sm text-muted-foreground">/ 50 GB</span>
              </div>
              <div className="h-1 bg-border rounded-full mt-2.5 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-primary to-secondary rounded-full" style={{ width: "2%" }} />
              </div>
              <div className="text-[11px] text-muted-foreground mt-1.5">{docs.length} files uploaded</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
