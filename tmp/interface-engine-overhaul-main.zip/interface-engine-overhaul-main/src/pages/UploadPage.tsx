import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const UploadPage = () => {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Contract");
  const [priority, setPriority] = useState("Normal");
  const [notes, setNotes] = useState("");
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);

  const processFile = (f: File) => {
    setFile(f);
    setTitle(f.name.replace(/\.[^/.]+$/, ""));
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files[0]) processFile(e.dataTransfer.files[0]);
  }, []);

  const handleSubmit = async () => {
    if (!title) { toast.error("Please enter a document title"); return; }
    setUploading(true);
    setProgress(0);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error("Not authenticated"); setUploading(false); return; }

    // Simulate progress
    const iv = setInterval(() => setProgress(p => Math.min(p + 15, 90)), 200);

    const { error } = await supabase.from("documents").insert({
      title,
      filename: file?.name || `${title}.pdf`,
      file_type: file?.type?.split("/").pop()?.toUpperCase() || "PDF",
      file_size: file?.size || 0,
      category,
      priority,
      status: "pending",
      version: "v1.0",
      version_notes: notes,
      uploaded_by: user.id,
    });

    clearInterval(iv);
    setProgress(100);
    setUploading(false);

    if (error) { toast.error(error.message); return; }
    toast.success("Document uploaded & submitted for approval!");
    setFile(null);
    setTitle("");
    setNotes("");
    setProgress(0);

    // Log audit
    await supabase.from("audit_logs").insert({
      user_id: user.id,
      action: "UPLOAD",
      detail: `Uploaded ${title}`,
    });
  };

  return (
    <div>
      {/* Drop zone */}
      <div
        onClick={() => document.getElementById("file-input")?.click()}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-2xl p-16 text-center bg-card cursor-pointer transition-all mb-6 ${dragOver ? "border-primary bg-primary/[0.03] shadow-[0_0_40px_hsl(187_100%_50%/0.08)]" : "border-border-bright hover:border-primary"}`}
      >
        <div className="text-5xl mb-4">📂</div>
        <div className="font-display text-xl font-bold mb-2">Drop your file here</div>
        <div className="text-muted-foreground text-[13px]">or click to browse from your computer</div>
        <div className="flex gap-2 justify-center mt-4 flex-wrap">
          {["PDF", "DOCX", "XLSX", "PNG", "JPG", "Max 50MB"].map(t => (
            <span key={t} className="font-mono text-[11px] bg-surface2 border border-border-bright rounded-md px-2.5 py-1 text-muted-foreground">{t}</span>
          ))}
        </div>
        <input type="file" id="file-input" className="hidden" onChange={e => e.target.files?.[0] && processFile(e.target.files[0])} />
      </div>

      {/* File preview */}
      {file && (
        <div className="bg-card border border-border rounded-xl mb-6 overflow-hidden">
          <div className="px-5 py-4 border-b border-border font-display text-sm font-bold">📎 File Preview</div>
          <div className="p-5">
            <div className="flex items-center gap-3.5 mb-4">
              <div className="w-[38px] h-[38px] bg-surface2 border border-border-bright rounded-lg flex items-center justify-center text-lg">📄</div>
              <div>
                <div className="font-semibold text-sm">{file.name}</div>
                <div className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</div>
              </div>
              <span className="ml-auto inline-flex items-center gap-1.5 text-[11px] font-mono bg-primary/[0.07] border border-primary/20 text-primary rounded px-2 py-0.5">🔒 Will be encrypted</span>
            </div>
            {progress > 0 && (
              <div className="h-1 bg-border rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all" style={{ width: `${progress}%` }} />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Form */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border font-display text-sm font-bold">Document Details</div>
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Document Title</label>
              <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Q4 Contract — Acme Corp"
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Category</label>
              <select value={category} onChange={e => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none cursor-pointer focus:border-primary">
                {["Contract", "NDA", "Proposal", "Report", "Other"].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Priority</label>
              <select value={priority} onChange={e => setPriority(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none cursor-pointer focus:border-primary">
                {["Normal", "High", "Urgent"].map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Version Notes</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="What changed in this version?"
              className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none resize-y min-h-[80px] transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
          </div>
          <div className="flex gap-2.5 pt-2">
            <button onClick={handleSubmit} disabled={uploading}
              className="px-4 py-2 rounded-lg text-[13px] font-semibold bg-primary/[0.12] text-primary border border-primary/30 hover:bg-primary/20 transition-all disabled:opacity-50">
              {uploading ? "Uploading..." : "⬆️ Upload & Submit for Approval"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UploadPage;
