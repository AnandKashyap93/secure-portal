import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Document {
  id: string;
  title: string;
  filename: string;
  file_type: string;
  file_size: number;
  version: string;
  status: string;
  created_at: string;
}

const statusStyles: Record<string, string> = {
  pending: "bg-warning/15 text-warning",
  approved: "bg-success/15 text-success",
  rejected: "bg-destructive/15 text-destructive",
  draft: "bg-muted-foreground/15 text-muted-foreground",
};

const Documents = () => {
  const [docs, setDocs] = useState<Document[]>([]);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    supabase.from("documents").select("*").order("created_at", { ascending: false })
      .then(({ data }) => { if (data) setDocs(data); });
  }, []);

  const filtered = filter === "all" ? docs : docs.filter(d => d.status === filter);
  const filters = ["all", "pending", "approved", "rejected", "draft"];

  return (
    <div>
      <div className="flex gap-2 mb-5 flex-wrap">
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3.5 py-1.5 rounded-md text-xs font-semibold border transition-all capitalize ${filter === f ? "bg-primary/10 text-primary border-primary/30" : "bg-transparent text-muted-foreground border-border-bright hover:text-foreground"}`}>
            {f} {f !== "all" ? `(${docs.filter(d => d.status === f).length})` : `(${docs.length})`}
          </button>
        ))}
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-10 text-center text-muted-foreground text-sm">No documents found.</div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="bg-card">
                <th className="text-left text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider px-4 py-2.5 border-b border-border">Name</th>
                <th className="text-left text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider px-4 py-2.5 border-b border-border">Type</th>
                <th className="text-left text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider px-4 py-2.5 border-b border-border">Version</th>
                <th className="text-left text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider px-4 py-2.5 border-b border-border">Size</th>
                <th className="text-left text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider px-4 py-2.5 border-b border-border">Date</th>
                <th className="text-left text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider px-4 py-2.5 border-b border-border">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(doc => (
                <tr key={doc.id} className="hover:bg-surface2 transition-colors cursor-pointer">
                  <td className="px-4 py-3 text-[13px] border-b border-border"><span className="mr-1.5">📄</span>{doc.title}</td>
                  <td className="px-4 py-3 border-b border-border"><span className="font-mono text-[11px] bg-surface2 border border-border-bright rounded px-1.5 py-0.5 text-muted-foreground">{doc.file_type}</span></td>
                  <td className="px-4 py-3 border-b border-border"><span className="font-mono text-[11px] bg-surface2 border border-border-bright rounded px-1.5 py-0.5 text-muted-foreground">{doc.version}</span></td>
                  <td className="px-4 py-3 text-[13px] border-b border-border">{(doc.file_size / 1024 / 1024).toFixed(1)} MB</td>
                  <td className="px-4 py-3 text-[11px] font-mono border-b border-border text-muted-foreground">{new Date(doc.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 border-b border-border"><span className={`text-[11px] font-semibold px-2 py-0.5 rounded capitalize ${statusStyles[doc.status] || statusStyles.draft}`}>{doc.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Documents;
