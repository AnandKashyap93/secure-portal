import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Comment {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  document_id: string;
}

interface Document {
  id: string;
  title: string;
}

const Comments = () => {
  const [docs, setDocs] = useState<Document[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");

  useEffect(() => {
    supabase.from("documents").select("id, title").order("created_at", { ascending: false })
      .then(({ data }) => {
        if (data && data.length > 0) {
          setDocs(data);
          setSelectedDoc(data[0].id);
        }
      });
  }, []);

  useEffect(() => {
    if (!selectedDoc) return;
    supabase.from("comments").select("*").eq("document_id", selectedDoc).order("created_at", { ascending: true })
      .then(({ data }) => { if (data) setComments(data); });
  }, [selectedDoc]);

  const handlePost = async () => {
    if (!newComment.trim() || !selectedDoc) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from("comments").insert({ document_id: selectedDoc, user_id: user.id, content: newComment.trim() });
    if (error) { toast.error(error.message); return; }
    setNewComment("");
    toast.success("Comment posted");
    // Refresh
    supabase.from("comments").select("*").eq("document_id", selectedDoc).order("created_at", { ascending: true })
      .then(({ data }) => { if (data) setComments(data); });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-5">
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border font-display text-sm font-bold">
          Comments {selectedDoc && `— ${docs.find(d => d.id === selectedDoc)?.title}`}
        </div>
        <div className="p-5">
          {comments.length === 0 ? (
            <div className="text-center text-muted-foreground text-sm py-6">No comments yet.</div>
          ) : (
            comments.map(c => (
              <div key={c.id} className="flex gap-3 mb-4">
                <div className="w-8 h-8 rounded-full gradient-brand flex items-center justify-center text-xs font-bold text-secondary-foreground shrink-0">
                  {c.user_id.substring(0, 1).toUpperCase()}
                </div>
                <div className="bg-surface2 border border-border rounded-xl px-3.5 py-3 flex-1">
                  <div className="flex justify-between mb-1.5">
                    <span className="text-[13px] font-semibold">User</span>
                    <span className="text-[11px] text-muted-foreground font-mono">{new Date(c.created_at).toLocaleString()}</span>
                  </div>
                  <p className="text-[13px] text-muted-foreground leading-relaxed">{c.content}</p>
                </div>
              </div>
            ))
          )}
          <div className="mt-4 pt-4 border-t border-border">
            <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Add Comment</label>
            <textarea value={newComment} onChange={e => setNewComment(e.target.value)} placeholder="Type your feedback..."
              className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none resize-y min-h-[80px] transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
            <button onClick={handlePost}
              className="mt-2 px-4 py-2 rounded-lg text-[13px] font-semibold bg-primary/[0.12] text-primary border border-primary/30 hover:bg-primary/20 transition-all">
              💬 Post Comment
            </button>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border font-display text-sm font-bold">Documents</div>
        {docs.map(doc => (
          <button key={doc.id} onClick={() => setSelectedDoc(doc.id)}
            className={`w-full flex items-center gap-3 px-5 py-3 border-b border-border transition-colors text-left ${selectedDoc === doc.id ? "bg-surface2" : "hover:bg-surface2"}`}>
            <div className="w-[38px] h-[38px] bg-surface2 border border-border-bright rounded-lg flex items-center justify-center text-lg">📄</div>
            <div className="text-[13px] font-semibold truncate">{doc.title}</div>
          </button>
        ))}
        {docs.length === 0 && <div className="p-5 text-center text-muted-foreground text-sm">No documents.</div>}
      </div>
    </div>
  );
};

export default Comments;
