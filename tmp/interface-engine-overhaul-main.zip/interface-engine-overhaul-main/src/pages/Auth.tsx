import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const Auth = () => {
  const [tab, setTab] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [regFirstName, setRegFirstName] = useState("");
  const [regLastName, setRegLastName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPass, setRegPass] = useState("");
  const [regRole, setRegRole] = useState("client");
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: loginEmail, password: loginPass });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Welcome back!");
    navigate("/dashboard");
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: regEmail,
      password: regPass,
      options: {
        data: { first_name: regFirstName, last_name: regLastName, role: regRole },
        emailRedirectTo: window.location.origin,
      },
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Check your email to confirm your account!");
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-background">
      {/* Grid background */}
      <div className="fixed inset-0 z-0 pointer-events-none grid-bg" />
      {/* Radial glows */}
      <div className="fixed inset-0 z-0 pointer-events-none" style={{
        background: "radial-gradient(ellipse 80% 60% at 50% -10%, hsl(187 100% 50% / 0.08) 0%, transparent 60%), radial-gradient(ellipse 50% 40% at 90% 80%, hsl(263 84% 55% / 0.06) 0%, transparent 50%)"
      }} />

      <div className="relative z-10 w-full max-w-[420px] bg-card border border-border-bright rounded-2xl p-10 glow-cyan animate-fade-up">
        {/* Logo */}
        <div className="flex items-center gap-2.5 mb-8">
          <div className="w-9 h-9 gradient-brand rounded-lg flex items-center justify-center text-lg">🔐</div>
          <div className="font-display font-extrabold text-xl tracking-tight">
            Secure<span className="text-primary">Portal</span>
          </div>
        </div>

        <h1 className="font-display text-2xl font-bold mb-1.5">
          {tab === "login" ? "Welcome back" : "Create account"}
        </h1>
        <p className="text-muted-foreground text-sm mb-7">
          {tab === "login" ? "Sign in to access your documents" : "Join the secure portal today"}
        </p>

        {/* Tabs */}
        <div className="flex gap-1 bg-background rounded-lg p-1 mb-6">
          <button
            onClick={() => setTab("login")}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${tab === "login" ? "bg-surface2 text-foreground shadow-[0_0_12px_hsl(187_100%_50%/0.1)]" : "text-muted-foreground"}`}
          >Login</button>
          <button
            onClick={() => setTab("register")}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${tab === "register" ? "bg-surface2 text-foreground shadow-[0_0_12px_hsl(187_100%_50%/0.1)]" : "text-muted-foreground"}`}
          >Register</button>
        </div>

        {tab === "login" ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Email</label>
              <input type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} required
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Password</label>
              <input type="password" value={loginPass} onChange={e => setLoginPass(e.target.value)} required
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-3 gradient-primary rounded-lg text-primary-foreground font-display font-bold text-sm tracking-wide hover:-translate-y-0.5 hover:glow-accent transition-all disabled:opacity-50">
              {loading ? "Signing in..." : "🔒 Sign In Securely"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">First Name</label>
                <input type="text" value={regFirstName} onChange={e => setRegFirstName(e.target.value)} placeholder="John" required
                  className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Last Name</label>
                <input type="text" value={regLastName} onChange={e => setRegLastName(e.target.value)} placeholder="Doe" required
                  className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Email</label>
              <input type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} placeholder="john@company.com" required
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Role</label>
              <select value={regRole} onChange={e => setRegRole(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none cursor-pointer focus:border-primary">
                <option value="client">Client</option>
                <option value="approver">Approver</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Password</label>
              <input type="password" value={regPass} onChange={e => setRegPass(e.target.value)} placeholder="Min 8 characters" required minLength={8}
                className="w-full px-3.5 py-2.5 bg-background border border-border-bright rounded-lg text-foreground text-sm outline-none transition-all focus:border-primary focus:shadow-[0_0_0_3px_hsl(187_100%_50%/0.1)]" />
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-3 gradient-primary rounded-lg text-primary-foreground font-display font-bold text-sm tracking-wide hover:-translate-y-0.5 hover:glow-accent transition-all disabled:opacity-50">
              {loading ? "Creating..." : "✅ Create Account"}
            </button>
          </form>
        )}

        <div className="mt-4 flex gap-2 justify-center">
          <span className="inline-flex items-center gap-1.5 text-xs font-mono bg-primary/[0.07] border border-primary/20 text-primary rounded px-2 py-0.5">🔒 AES-256</span>
          <span className="inline-flex items-center gap-1.5 text-xs font-mono bg-primary/[0.07] border border-primary/20 text-primary rounded px-2 py-0.5">🛡️ JWT Auth</span>
          <span className="inline-flex items-center gap-1.5 text-xs font-mono bg-primary/[0.07] border border-primary/20 text-primary rounded px-2 py-0.5">🔏 HTTPS</span>
        </div>
      </div>
    </div>
  );
};

export default Auth;
