import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Document {
  id: string;
  title: string;
  filename: string;
  status: string;
  version: string;
  file_type: string;
  file_size: number;
  category: string;
  priority: string;
  version_notes: string | null;
  created_at: string;
}

const statusStyles: Record<string, string> = {
  pending: "bg-warning/15 text-warning",
  approved: "bg-success/15 text-success",
  rejected: "bg-destructive/15 text-destructive",
  draft: "bg-muted-foreground/15 text-muted-foreground",
};

const Approvals = () => {
  const [docs, setDocs] = useState<Document[]>([]);
  const [filter, setFilter] = useState("all");

  const fetchDocs = () => {
    supabase.from("documents").select("*").order("created_at", { ascending: false })
      .then(({ data }) => { if (data) setDocs(data); });
  };

  useEffect(() => { fetchDocs(); }, []);

  const handleAction = async (id: string, status: "approved" | "rejected") => {
    const { error } = await supabase.from("documents").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success(`Document ${status}!`);
    fetchDocs();

    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from("audit_logs").insert({
        user_id: user.id,
        action: status === "approved" ? "APPROVE" : "REJECT",
        detail: `${status === "approved" ? "Approved" : "Rejected"} document ${id}`,
      });
    }
  };

  const filtered = filter === "all" ? docs : docs.filter(d => d.status === filter);

  return (
    <div>
      <div className="flex gap-2 mb-5 flex-wrap">
        {["all", "pending", "approved", "rejected"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3.5 py-1.5 rounded-md text-xs font-semibold border transition-all capitalize ${filter === f ? "bg-primary/10 text-primary border-primary/30" : "bg-transparent text-muted-foreground border-border-bright"}`}>
            {f} {f !== "all" ? `(${docs.filter(d => d.status === f).length})` : ""}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="bg-card border border-border rounded-xl p-10 text-center text-muted-foreground text-sm">No documents to review.</div>
      ) : (
        filtered.map(doc => (
          <div key={doc.id} className="bg-card border border-border rounded-xl p-5 mb-3.5 hover:border-border-bright transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="font-display text-[15px] font-bold">{doc.title}</div>
                <div className="text-[11px] text-muted-foreground font-mono mt-0.5">{doc.filename} · {doc.version} · {new Date(doc.created_at).toLocaleDateString()}</div>
              </div>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded capitalize ${statusStyles[doc.status]}`}>{doc.status}</span>
            </div>
            <div className="flex gap-1.5 flex-wrap mb-3">
              <span className="font-mono text-[11px] bg-surface2 rounded px-2 py-0.5 text-muted-foreground">{doc.category}</span>
              <span className="font-mono text-[11px] bg-surface2 rounded px-2 py-0.5 text-muted-foreground">{doc.priority}</span>
              <span className="font-mono text-[11px] bg-surface2 rounded px-2 py-0.5 text-muted-foreground">{doc.file_type}</span>
              <span className="font-mono text-[11px] bg-surface2 rounded px-2 py-0.5 text-muted-foreground">{(doc.file_size / 1024 / 1024).toFixed(1)} MB</span>
            </div>
            {doc.version_notes && <p className="text-[13px] text-muted-foreground mb-3.5 leading-relaxed">{doc.version_notes}</p>}
            <div className="flex gap-2">
              {doc.status === "pending" && (
                <>
                  <button onClick={() => handleAction(doc.id, "approved")}
                    className="px-3.5 py-1.5 rounded-lg text-[13px] font-semibold bg-success/[0.12] text-success border border-success/30 hover:bg-success/20 transition-all">✅ Approve</button>
                  <button onClick={() => handleAction(doc.id, "rejected")}
                    className="px-3.5 py-1.5 rounded-lg text-[13px] font-semibold bg-destructive/[0.12] text-destructive border border-destructive/30 hover:bg-destructive/20 transition-all">✗ Reject</button>
                </>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default Approvals;
